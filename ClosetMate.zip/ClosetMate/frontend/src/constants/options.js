// Dropdown options shared by the clothing forms and (later) filters
export const CATEGORIES = [
  'Tops',
  'Bottoms',
  'Dresses',
  'Outerwear',
  'Shoes',
  'Accessories',
];

export const TYPES = [
  'T-Shirt',
  'Shirt',
  'Hoodie',
  'Sweatshirt',
  'Jeans',
  'Trousers',
  'Skirt',
  'Dress',
  'Jacket',
  'Coat',
  'Sneakers',
  'Formal Shoes',
  'Cap',
  'Watch',
  'Bag',
  'Belt',
  'Other',
];

export const COLORS = [
  'Black',
  'White',
  'Blue',
  'Red',
  'Green',
  'Brown',
  'Grey',
  'Pink',
  'Beige',
  'Other',
];

export const SEASONS = [
  'Summer',
  'Winter',
  'Spring',
  'Autumn',
  'All Season',
];

export const OCCASIONS = [
  'Casual',
  'College',
  'Formal',
  'Party',
  'Workout',
  'Travel',
];

export const CLOTHING_GENDERS = ['Unisex', 'Male', 'Female'];

export const USER_GENDERS = ['Male', 'Female', 'Other'];
