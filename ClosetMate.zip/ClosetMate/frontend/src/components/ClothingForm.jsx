import { useState } from 'react';
import {
  CATEGORIES,
  TYPES,
  COLORS,
  SEASONS,
  OCCASIONS,
  CLOTHING_GENDERS,
} from '../constants/options';
import AlertMessage from './AlertMessage';

const EMPTY_VALUES = {
  name: '',
  category: '',
  type: '',
  color: '',
  season: 'All Season',
  occasion: 'Casual',
  gender: 'Unisex',
  brand: '',
  size: '',
  image: '',
};

function ClothingForm({
  initialValues,
  onSubmit,
  submitLabel = 'Save',
  submitting = false,
}) {
  const [values, setValues] = useState({ ...EMPTY_VALUES, ...initialValues });
  const [errors, setErrors] = useState({});
  const [apiError, setApiError] = useState('');
  const [imageBroken, setImageBroken] = useState(false);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setValues((prev) => ({ ...prev, [name]: value }));
    if (name === 'image') setImageBroken(false);
  };

  const validate = () => {
    const next = {};
    if (!values.name.trim()) next.name = 'Clothing name is required';
    if (!values.category) next.category = 'Please select a category';
    if (values.image.trim() && !/^https?:\/\//i.test(values.image.trim())) {
      next.image = 'Image must be a valid URL starting with http:// or https://';
    }
    setErrors(next);
    return Object.keys(next).length === 0;
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setApiError('');
    if (!validate()) return;

    const payload = { ...values, image: values.image.trim() };
    try {
      await onSubmit(payload);
    } catch (err) {
      setApiError(err.message);
    }
  };

  return (
    <form onSubmit={handleSubmit} noValidate>
      {apiError && <AlertMessage type="danger" message={apiError} />}

      <div className="row g-3">
        <div className="col-12">
          <label className="form-label" htmlFor="name">
            Clothing Name <span className="text-danger">*</span>
          </label>
          <input
            id="name"
            name="name"
            className={'form-control' + (errors.name ? ' is-invalid' : '')}
            placeholder="e.g. Black Hoodie"
            value={values.name}
            onChange={handleChange}
          />
          {errors.name && <div className="invalid-feedback">{errors.name}</div>}
        </div>

        <div className="col-md-6">
          <label className="form-label" htmlFor="category">
            Category <span className="text-danger">*</span>
          </label>
          <select
            id="category"
            name="category"
            className={'form-select' + (errors.category ? ' is-invalid' : '')}
            value={values.category}
            onChange={handleChange}
          >
            <option value="">Select category</option>
            {CATEGORIES.map((c) => (
              <option key={c} value={c}>
                {c}
              </option>
            ))}
          </select>
          {errors.category && (
            <div className="invalid-feedback">{errors.category}</div>
          )}
        </div>

        <div className="col-md-6">
          <label className="form-label" htmlFor="type">
            Type
          </label>
          <select
            id="type"
            name="type"
            className="form-select"
            value={values.type}
            onChange={handleChange}
          >
            <option value="">Select type</option>
            {TYPES.map((t) => (
              <option key={t} value={t}>
                {t}
              </option>
            ))}
          </select>
        </div>

        <div className="col-md-6">
          <label className="form-label" htmlFor="color">
            Color
          </label>
          <select
            id="color"
            name="color"
            className="form-select"
            value={values.color}
            onChange={handleChange}
          >
            <option value="">Select color</option>
            {COLORS.map((c) => (
              <option key={c} value={c}>
                {c}
              </option>
            ))}
          </select>
        </div>

        <div className="col-md-6">
          <label className="form-label" htmlFor="brand">
            Brand
          </label>
          <input
            id="brand"
            name="brand"
            className="form-control"
            placeholder="e.g. Nike"
            value={values.brand}
            onChange={handleChange}
          />
        </div>

        <div className="col-md-4">
          <label className="form-label" htmlFor="season">
            Season
          </label>
          <select
            id="season"
            name="season"
            className="form-select"
            value={values.season}
            onChange={handleChange}
          >
            {SEASONS.map((s) => (
              <option key={s} value={s}>
                {s}
              </option>
            ))}
          </select>
        </div>

        <div className="col-md-4">
          <label className="form-label" htmlFor="occasion">
            Occasion
          </label>
          <select
            id="occasion"
            name="occasion"
            className="form-select"
            value={values.occasion}
            onChange={handleChange}
          >
            {OCCASIONS.map((o) => (
              <option key={o} value={o}>
                {o}
              </option>
            ))}
          </select>
        </div>

        <div className="col-md-4">
          <label className="form-label" htmlFor="size">
            Size
          </label>
          <input
            id="size"
            name="size"
            className="form-control"
            placeholder="e.g. M"
            value={values.size}
            onChange={handleChange}
          />
        </div>

        <div className="col-md-4">
          <label className="form-label" htmlFor="gender">
            Gender
          </label>
          <select
            id="gender"
            name="gender"
            className="form-select"
            value={values.gender}
            onChange={handleChange}
          >
            {CLOTHING_GENDERS.map((g) => (
              <option key={g} value={g}>
                {g}
              </option>
            ))}
          </select>
        </div>

        <div className="col-12">
          <label className="form-label" htmlFor="image">
            Image URL
          </label>
          <input
            id="image"
            name="image"
            className={'form-control' + (errors.image ? ' is-invalid' : '')}
            placeholder="https://example.com/my-hoodie.jpg"
            value={values.image}
            onChange={handleChange}
          />
          {errors.image && <div className="invalid-feedback">{errors.image}</div>}
          <div className="form-text">
            Paste a link to an image. You can leave this empty and a placeholder
            will be shown.
          </div>
        </div>

        {values.image.trim() && !imageBroken && (
          <div className="col-12">
            <div className="cm-image-preview">
              <img
                src={values.image.trim()}
                alt="Preview"
                onError={() => setImageBroken(true)}
              />
            </div>
          </div>
        )}
      </div>

      <div className="d-flex gap-2 mt-4">
        <button
          type="submit"
          className="btn cm-btn-dark px-4"
          disabled={submitting}
        >
          {submitting ? (
            <>
              <span className="spinner-border spinner-border-sm me-2"></span>
              Saving...
            </>
          ) : (
            submitLabel
          )}
        </button>
      </div>
    </form>
  );
}

export default ClothingForm;
