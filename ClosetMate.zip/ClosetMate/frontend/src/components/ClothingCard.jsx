import { Link } from 'react-router-dom';

function ClothingCard({ item, onToggleFavorite, onMarkWorn, onDelete }) {
  return (
    <div className="cm-clothing-card card h-100">
      <div className="cm-clothing-image">
        {item.image ? (
          <img src={item.image} alt={item.name} loading="lazy" />
        ) : (
          <div className="cm-image-placeholder">
            <i className="bi bi-image"></i>
          </div>
        )}

        <button
          type="button"
          className={
            'cm-fav-btn' + (item.isFavorite ? ' is-favorite' : '')
          }
          onClick={() => onToggleFavorite(item)}
          aria-label="Toggle favorite"
          title={item.isFavorite ? 'Remove from favorites' : 'Add to favorites'}
        >
          <i
            className={item.isFavorite ? 'bi bi-heart-fill' : 'bi bi-heart'}
          ></i>
        </button>
      </div>

      <div className="card-body">
        <h6 className="fw-semibold text-truncate mb-1" title={item.name}>
          {item.name}
        </h6>
        <p className="text-muted small mb-1">
          {item.category}
          {item.color ? ` • ${item.color}` : ''}
        </p>
        <p className="text-muted small mb-2">
          {item.season} • {item.occasion}
        </p>
        <span className="badge cm-badge">
          Worn {item.timesWorn} {item.timesWorn === 1 ? 'time' : 'times'}
        </span>
      </div>

      <div className="card-footer bg-white border-0 pt-0">
        <div className="d-flex gap-2 mb-2">
          <Link
            to={`/closet/edit/${item._id}`}
            className="btn btn-sm cm-btn-outline flex-fill"
          >
            <i className="bi bi-pencil me-1"></i>Edit
          </Link>
          <button
            type="button"
            className="btn btn-sm btn-outline-danger flex-fill"
            onClick={() => onDelete(item)}
          >
            <i className="bi bi-trash me-1"></i>Delete
          </button>
        </div>
        <button
          type="button"
          className="btn btn-sm cm-btn-dark w-100"
          onClick={() => onMarkWorn(item)}
        >
          <i className="bi bi-check2-circle me-1"></i>Mark as Worn
        </button>
      </div>
    </div>
  );
}

export default ClothingCard;
