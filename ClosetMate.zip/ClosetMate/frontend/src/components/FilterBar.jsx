import {
  CATEGORIES,
  COLORS,
  SEASONS,
  OCCASIONS,
  CLOTHING_GENDERS,
} from '../constants/options';

function FilterBar({ filters, onChange, onClear }) {
  const select = (name, label, options) => (
    <div className="col-6 col-md-4 col-lg">
      <label htmlFor={`filter-${name}`} className="form-label small text-muted mb-1">
        {label}
      </label>
      <select
        id={`filter-${name}`}
        className="form-select form-select-sm"
        value={filters[name]}
        onChange={(e) => onChange(name, e.target.value)}
      >
        <option value="">All</option>
        {options.map((o) => (
          <option key={o} value={o}>
            {o}
          </option>
        ))}
      </select>
    </div>
  );

  return (
    <div className="cm-filter-bar">
      <div className="row g-3 align-items-end">
        {select('category', 'Category', CATEGORIES)}
        {select('color', 'Color', COLORS)}
        {select('gender', 'Gender', CLOTHING_GENDERS)}
        {select('season', 'Season', SEASONS)}
        {select('occasion', 'Occasion', OCCASIONS)}

        <div className="col-6 col-md-4 col-lg">
          <label htmlFor="filter-sort" className="form-label small text-muted mb-1">
            Sort
          </label>
          <select
            id="filter-sort"
            className="form-select form-select-sm"
            value={filters.sort}
            onChange={(e) => onChange('sort', e.target.value)}
          >
            <option value="newest">Newest</option>
            <option value="oldest">Oldest</option>
            <option value="mostWorn">Most Worn</option>
            <option value="leastWorn">Least Worn</option>
            <option value="nameAsc">Name A-Z</option>
            <option value="nameDesc">Name Z-A</option>
          </select>
        </div>

        <div className="col-6 col-md-4 col-lg-auto d-flex gap-2 align-items-end">
          <button
            type="button"
            className={
              'btn btn-sm ' +
              (filters.favorites ? 'cm-btn-dark' : 'cm-btn-outline')
            }
            onClick={() => onChange('favorites', !filters.favorites)}
            title="Show favorites only"
          >
            <i
              className={
                (filters.favorites ? 'bi bi-heart-fill' : 'bi bi-heart') + ' me-1'
              }
            ></i>
            Favorites
          </button>
          <button
            type="button"
            className="btn btn-sm btn-light border"
            onClick={onClear}
          >
            Clear
          </button>
        </div>
      </div>
    </div>
  );
}

export default FilterBar;
