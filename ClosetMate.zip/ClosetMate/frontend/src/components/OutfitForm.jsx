import { useState } from 'react';
import AlertMessage from '../components/AlertMessage';
import LoadingSpinner from '../components/LoadingSpinner';

function OutfitForm({
  initial = {},
  clothingItems,
  loadingItems,
  onSubmit,
  submitLabel = 'Save Outfit',
}) {
  const [name, setName] = useState(initial.name || '');
  const [occasion, setOccasion] = useState(initial.occasion || 'Casual');
  const [notes, setNotes] = useState(initial.notes || '');
  const [selected, setSelected] = useState(
    new Set((initial.items || []).map((i) => (i._id ? i._id : i)))
  );
  const [error, setError] = useState('');
  const [submitting, setSubmitting] = useState(false);

  const toggleItem = (id) => {
    setSelected((prev) => {
      const next = new Set(prev);
      if (next.has(id)) {
        next.delete(id);
      } else {
        next.add(id);
      }
      return next;
    });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError('');
    if (!name.trim()) {
      setError('Please give your outfit a name');
      return;
    }
    setSubmitting(true);
    try {
      await onSubmit({
        name,
        occasion,
        notes,
        items: [...selected],
      });
    } catch (err) {
      setError(err.message);
      setSubmitting(false);
    }
  };

  const selectedItems = clothingItems.filter((c) => selected.has(c._id));

  return (
    <form onSubmit={handleSubmit} noValidate>
      {error && <AlertMessage type="danger" message={error} />}

      <div className="mb-3">
        <label htmlFor="outfitName" className="form-label">
          Outfit name <span className="text-danger">*</span>
        </label>
        <input
          id="outfitName"
          type="text"
          className="form-control cm-input"
          value={name}
          onChange={(e) => setName(e.target.value)}
          placeholder="e.g. Casual Weekend Look"
          required
        />
      </div>

      <div className="row g-3 mb-3">
        <div className="col-12 col-md-6">
          <label htmlFor="outfitOccasion" className="form-label">
            Occasion
          </label>
          <select
            id="outfitOccasion"
            className="form-select cm-input"
            value={occasion}
            onChange={(e) => setOccasion(e.target.value)}
          >
            <option value="Casual">Casual</option>
            <option value="College">College</option>
            <option value="Formal">Formal</option>
            <option value="Party">Party</option>
            <option value="Workout">Workout</option>
            <option value="Travel">Travel</option>
          </select>
        </div>
        <div className="col-12 col-md-6">
          <label htmlFor="outfitNotes" className="form-label">
            Notes (optional)
          </label>
          <input
            id="outfitNotes"
            type="text"
            className="form-control cm-input"
            value={notes}
            onChange={(e) => setNotes(e.target.value)}
            placeholder="e.g. Goes with white sneakers"
          />
        </div>
      </div>

      <div className="mb-3">
        <div className="d-flex justify-content-between align-items-center mb-2">
          <label className="form-label mb-0">
            Pick clothing items{' '}
            <span className="text-muted small">
              ({selectedItems.length} selected)
            </span>
          </label>
        </div>

        {loadingItems ? (
          <LoadingSpinner message="Loading your closet..." />
        ) : clothingItems.length === 0 ? (
          <div className="cm-panel text-center text-muted py-4">
            Your closet is empty.{' '}
            <a href="/closet/add" className="cm-link">
              Add clothing first
            </a>{' '}
            so you can build outfits.
          </div>
        ) : (
          <div className="row g-2">
            {clothingItems.map((item) => {
              const checked = selected.has(item._id);
              return (
                <div className="col-4 col-sm-3 col-lg-2" key={item._id}>
                  <label className="cm-pick-tile">
                    <input
                      type="checkbox"
                      className="form-check-input cm-pick-check"
                      checked={checked}
                      onChange={() => toggleItem(item._id)}
                    />
                    <span className="cm-pick-media">
                      {item.image ? (
                        <img src={item.image} alt={item.name} loading="lazy" />
                      ) : (
                        <i className="bi bi-image"></i>
                      )}
                    </span>
                    <span className="cm-pick-label text-truncate">
                      {item.name}
                    </span>
                  </label>
                </div>
              );
            })}
          </div>
        )}
      </div>

      <button
        type="submit"
        className="btn cm-btn-dark px-4"
        disabled={submitting}
      >
        <i className="bi bi-check2-circle me-1"></i>
        {submitting ? 'Saving...' : submitLabel}
      </button>
    </form>
  );
}

export default OutfitForm;