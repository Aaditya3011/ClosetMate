import { Link } from 'react-router-dom';

function OutfitCard({ outfit, onDelete }) {
  const items = outfit.items || [];
  const shown = items.slice(0, 4);
  const extra = items.length - shown.length;

  return (
    <div className="cm-outfit-card card h-100">
      <div className="card-body">
        <div className="d-flex justify-content-between align-items-start mb-2">
          <h5 className="fw-bold mb-0 text-truncate" title={outfit.name}>
            {outfit.name}
          </h5>
          <span className="badge cm-badge ms-2">
            <i className="bi bi-tag me-1"></i>
            {outfit.occasion}
          </span>
        </div>

        <p className="text-muted small mb-2">
          {items.length} {items.length === 1 ? 'item' : 'items'}
        </p>

        {items.length === 0 ? (
          <div className="cm-outfit-thumb-bare">
            <i className="bi bi-share"></i>
          </div>
        ) : (
          <div className="d-flex flex-wrap gap-1 mb-3">
            {shown.map((item) => (
              <div className="cm-outfit-thumb" key={item._id} title={item.name}>
                {item.image ? (
                  <img src={item.image} alt={item.name} loading="lazy" />
                ) : (
                  <i className="bi bi-image"></i>
                )}
              </div>
            ))}
            {extra > 0 && (
              <div className="cm-outfit-thumb cm-outfit-thumb-more">
                +{extra}
              </div>
            )}
          </div>
        )}

        {outfit.notes && (
          <p className="text-muted small mb-3">
            <i className="bi bi-chat-left-text me-1"></i>
            {outfit.notes}
          </p>
        )}
      </div>

      <div className="card-footer bg-white border-0 pt-0">
        <div className="d-flex gap-2">
          <Link
            to={`/outfits/edit/${outfit._id}`}
            className="btn btn-sm cm-btn-outline flex-fill"
          >
            <i className="bi bi-pencil me-1"></i>Edit
          </Link>
          <button
            type="button"
            className="btn btn-sm btn-outline-danger flex-fill"
            onClick={() => onDelete(outfit)}
          >
            <i className="bi bi-trash me-1"></i>Delete
          </button>
        </div>
      </div>
    </div>
  );
}

export default OutfitCard;