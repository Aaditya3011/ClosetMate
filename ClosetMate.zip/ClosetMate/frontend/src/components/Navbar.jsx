import { Link, NavLink, useNavigate } from 'react-router-dom'
import Offcanvas from 'bootstrap/js/dist/offcanvas'
import { useAuth } from '../context/AuthContext'

function Navbar() {
  const { user, token, logout } = useAuth()
  const navigate = useNavigate()

  const navLinkClass = ({ isActive }) =>
    'nav-link' + (isActive ? ' active' : '')

  const closeMenu = () => {
    const el = document.getElementById('mobileMenu')
    if (el) Offcanvas.getOrCreateInstance(el).hide()
  }

  const handleLogout = () => {
    closeMenu()
    navigate('/')
    logout()
  }

  const initials = user?.name?.trim()?.charAt(0)?.toUpperCase() || 'U'

  const avatar =
    user?.profileImage ? (
      <img src={user.profileImage} alt="" className="cm-avatar-img" />
    ) : (
      <span className="cm-avatar">{initials}</span>
    )

  return (
    <nav className="navbar navbar-expand-lg cm-navbar sticky-top">
      <div className="container">
        <Link className="navbar-brand cm-brand" to={token ? '/dashboard' : '/'}>
          Closet<i className="bi bi-heart-fill ms-1"></i>Mate
        </Link>

        <button
          className="navbar-toggler border-0"
          type="button"
          data-bs-toggle="offcanvas"
          data-bs-target="#mobileMenu"
          aria-controls="mobileMenu"
          aria-label="Open menu"
        >
          <i className="bi bi-list fs-3"></i>
        </button>

        <div
          className="offcanvas offcanvas-end"
          tabIndex="-1"
          id="mobileMenu"
          aria-labelledby="mobileMenuLabel"
        >
          <div className="offcanvas-header border-bottom">
            <h5 className="offcanvas-title cm-brand" id="mobileMenuLabel">
              Closet<i className="bi bi-heart-fill ms-1"></i>Mate
            </h5>
            <button
              type="button"
              className="btn-close"
              data-bs-dismiss="offcanvas"
              aria-label="Close"
            ></button>
          </div>

          <div className="offcanvas-body">
            <ul className="navbar-nav ms-auto align-items-lg-center gap-lg-1">
              {token ? (
                <>
                  <li className="nav-item">
                    <NavLink className={navLinkClass} to="/dashboard" onClick={closeMenu}>
                      Dashboard
                    </NavLink>
                  </li>
                  <li className="nav-item">
                    <NavLink className={navLinkClass} to="/closet" onClick={closeMenu}>
                      My Closet
                    </NavLink>
                  </li>
                  <li className="nav-item">
                    <NavLink className={navLinkClass} to="/outfits" onClick={closeMenu}>
                      Outfits
                    </NavLink>
                  </li>
                  <li className="nav-item">
                    <NavLink className={navLinkClass} to="/suggestions" onClick={closeMenu}>
                      Suggestions
                    </NavLink>
                  </li>

                  <li className="nav-item mt-3 mt-lg-0 ms-lg-3">
                    <div className="cm-user-menu">
                      <button
                        type="button"
                        className="cm-user-btn dropdown-toggle"
                        data-bs-toggle="dropdown"
                        aria-expanded="false"
                      >
                        {avatar}
                        <span className="d-none d-lg-inline cm-nav-username ms-1">
                          {user?.name}
                        </span>
                      </button>
                      <ul className="dropdown-menu dropdown-menu-end cm-dropdown">
                        <li>
                          <span className="dropdown-item-text small text-muted text-truncate">
                            {user?.email}
                          </span>
                        </li>
                        <li>
                          <hr className="dropdown-divider" />
                        </li>
                        <li>
                          <Link className="dropdown-item" to="/profile" onClick={closeMenu}>
                            <i className="bi bi-person me-2"></i>Profile
                          </Link>
                        </li>
                        <li>
                          <Link className="dropdown-item" to="/dashboard" onClick={closeMenu}>
                            <i className="bi bi-speedometer2 me-2"></i>Dashboard
                          </Link>
                        </li>
                        <li>
                          <Link className="dropdown-item" to="/closet" onClick={closeMenu}>
                            <i className="bi bi-grid me-2"></i>My Closet
                          </Link>
                        </li>
                        <li>
                          <hr className="dropdown-divider" />
                        </li>
                        <li>
                          <button
                            type="button"
                            className="dropdown-item text-danger"
                            onClick={handleLogout}
                          >
                            <i className="bi bi-box-arrow-right me-2"></i>Logout
                          </button>
                        </li>
                      </ul>
                    </div>
                  </li>
                </>
              ) : (
                <>
                  <li className="nav-item">
                    <NavLink className={navLinkClass} to="/" onClick={closeMenu}>
                      Home
                    </NavLink>
                  </li>
                  <li className="nav-item">
                    <NavLink className={navLinkClass} to="/login" onClick={closeMenu}>
                      Login
                    </NavLink>
                  </li>
                  <li className="nav-item ms-lg-2 ms-0 mt-3 mt-lg-0 w-100 w-lg-auto">
                    <Link
                      className="btn cm-btn-dark w-100 w-lg-auto"
                      to="/register"
                      onClick={closeMenu}
                    >
                      Get Started
                    </Link>
                  </li>
                </>
              )}
            </ul>
          </div>
        </div>
      </div>
    </nav>
  )
}

export default Navbar
