import { useEffect, useRef } from 'react';
import Modal from 'bootstrap/js/dist/modal';

// A controlled Bootstrap modal used for delete confirmations
function ConfirmationModal({
  show,
  title,
  message,
  confirmLabel = 'Delete',
  confirmClass = 'btn-danger',
  loading = false,
  onConfirm,
  onCancel,
}) {
  const modalRef = useRef(null);
  const instanceRef = useRef(null);

  useEffect(() => {
    instanceRef.current = new Modal(modalRef.current, {
      backdrop: 'static',
    });
    return () => instanceRef.current?.dispose();
  }, []);

  useEffect(() => {
    if (!instanceRef.current) return;
    if (show) {
      instanceRef.current.show();
    } else {
      instanceRef.current.hide();
    }
  }, [show]);

  return (
    <div className="modal fade" ref={modalRef} tabIndex="-1">
      <div className="modal-dialog modal-dialog-centered">
        <div className="modal-content">
          <div className="modal-header">
            <h5 className="modal-title">{title}</h5>
            <button
              type="button"
              className="btn-close"
              onClick={onCancel}
              aria-label="Close"
              disabled={loading}
            ></button>
          </div>
          <div className="modal-body">{message}</div>
          <div className="modal-footer">
            <button
              type="button"
              className="btn cm-btn-outline"
              onClick={onCancel}
              disabled={loading}
            >
              Cancel
            </button>
            <button
              type="button"
              className={`btn ${confirmClass}`}
              onClick={onConfirm}
              disabled={loading}
            >
              {loading ? (
                <>
                  <span className="spinner-border spinner-border-sm me-2"></span>
                  Please wait...
                </>
              ) : (
                confirmLabel
              )}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}

export default ConfirmationModal;
