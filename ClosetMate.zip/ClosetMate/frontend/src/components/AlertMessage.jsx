import { useState } from 'react';

function AlertMessage({ type = 'danger', message, dismissible = true }) {
  const [visible, setVisible] = useState(true);

  if (!visible || !message) return null;

  return (
    <div
      className={`alert alert-${type} d-flex align-items-center justify-content-between`}
      role="alert"
    >
      <span className="d-flex align-items-center">
        <i
          className={`bi ${
            type === 'danger'
              ? 'bi-exclamation-triangle'
              : type === 'success'
                ? 'bi-check-circle'
                : 'bi-info-circle'
          } me-2`}
        ></i>
        {message}
      </span>
      {dismissible && (
        <button
          type="button"
          className="btn-close"
          onClick={() => setVisible(false)}
          aria-label="Close"
        ></button>
      )}
    </div>
  );
}

export default AlertMessage;
