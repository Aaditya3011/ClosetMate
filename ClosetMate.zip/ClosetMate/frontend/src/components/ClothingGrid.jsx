import ClothingCard from './ClothingCard';

function ClothingGrid({ clothes, onToggleFavorite, onMarkWorn, onDelete }) {
  return (
    <div className="row g-4">
      {clothes.map((item) => (
        <div className="col-12 col-sm-6 col-lg-4 col-xxl-3" key={item._id}>
          <ClothingCard
            item={item}
            onToggleFavorite={onToggleFavorite}
            onMarkWorn={onMarkWorn}
            onDelete={onDelete}
          />
        </div>
      ))}
    </div>
  );
}

export default ClothingGrid;
