function SearchBar({ value, onChange, placeholder = 'Search...' }) {
  return (
    <div className="cm-search">
      <i className="bi bi-search cm-search-icon"></i>
      <input
        type="text"
        className="form-control"
        value={value}
        placeholder={placeholder}
        onChange={(e) => onChange(e.target.value)}
        aria-label="Search"
      />
      {value && (
        <button
          type="button"
          className="cm-search-clear"
          onClick={() => onChange('')}
          aria-label="Clear search"
        >
          <i className="bi bi-x-lg"></i>
        </button>
      )}
    </div>
  );
}

export default SearchBar;
