import { Link } from 'react-router-dom'

function EmptyState({ icon = 'bi-box', title, text, actionLabel, actionTo }) {
  return (
    <div className="cm-empty-state text-center py-5">
      <div className="cm-empty-icon mb-3">
        <i className={`bi ${icon}`}></i>
      </div>
      <h4 className="fw-semibold mb-2">{title}</h4>
      {text && <p className="text-muted mb-4">{text}</p>}
      {actionLabel && actionTo && (
        <Link to={actionTo} className="btn cm-btn-dark px-4">
          {actionLabel}
        </Link>
      )}
    </div>
  );
}

export default EmptyState;
