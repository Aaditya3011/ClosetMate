function Footer() {
  return (
    <footer className="cm-footer mt-auto">
      <div className="container py-4">
        <div className="row align-items-center g-3">
          <div className="col-12 col-md-4 text-center text-md-start">
            <span className="cm-brand cm-brand-light">
              Closet<i className="bi bi-heart-fill ms-1"></i>Mate
            </span>
          </div>
          <div className="col-12 col-md-4 text-center text-muted small">
            Your wardrobe, organized.
          </div>
          <div className="col-12 col-md-4 text-center text-md-end text-muted small">
            &copy; {new Date().getFullYear()} ClosetMate
          </div>
        </div>
      </div>
    </footer>
  )
}

export default Footer
