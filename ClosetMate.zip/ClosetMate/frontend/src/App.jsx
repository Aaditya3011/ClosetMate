import { BrowserRouter, Routes, Route, Link } from 'react-router-dom';
import { AuthProvider } from './context/AuthContext';
import Navbar from './components/Navbar';
import Footer from './components/Footer';
import ProtectedRoute from './components/ProtectedRoute';
import Landing from './pages/Landing';
import Login from './pages/Login';
import Register from './pages/Register';
import Closet from './pages/Closet';
import AddClothing from './pages/AddClothing';
import EditClothing from './pages/EditClothing';
import Dashboard from './pages/Dashboard';
import Profile from './pages/Profile';
import Outfits from './pages/Outfits';
import CreateOutfit from './pages/CreateOutfit';
import EditOutfit from './pages/EditOutfit';
import Suggestions from './pages/Suggestions';

function Placeholder({ title }) {
  return (
    <div className="container py-5 text-center">
      <h1 className="fw-bold">{title}</h1>
      <p className="text-muted">This page will be built in a later phase.</p>
      <Link to="/dashboard" className="btn cm-btn-outline">
        Back to Dashboard
      </Link>
    </div>
  );
}

function App() {
  return (
    <AuthProvider>
      <BrowserRouter>
        <div className="d-flex flex-column min-vh-100">
          <Navbar />
          <main className="flex-grow-1">
            <Routes>
              <Route path="/" element={<Landing />} />
              <Route path="/login" element={<Login />} />
              <Route path="/register" element={<Register />} />

              <Route
                path="/dashboard"
                element={
                  <ProtectedRoute>
                    <Dashboard />
                  </ProtectedRoute>
                }
              />
              <Route
                path="/closet"
                element={
                  <ProtectedRoute>
                    <Closet />
                  </ProtectedRoute>
                }
              />
              <Route
                path="/closet/add"
                element={
                  <ProtectedRoute>
                    <AddClothing />
                  </ProtectedRoute>
                }
              />
              <Route
                path="/closet/edit/:id"
                element={
                  <ProtectedRoute>
                    <EditClothing />
                  </ProtectedRoute>
                }
              />
              <Route
                path="/outfits/new"
                element={
                  <ProtectedRoute>
                    <CreateOutfit />
                  </ProtectedRoute>
                }
              />
              <Route
                path="/outfits"
                element={
                  <ProtectedRoute>
                    <Outfits />
                  </ProtectedRoute>
                }
              />
              <Route
                path="/outfits/edit/:id"
                element={
                  <ProtectedRoute>
                    <EditOutfit />
                  </ProtectedRoute>
                }
              />
              <Route
                path="/suggestions"
                element={
                  <ProtectedRoute>
                    <Suggestions />
                  </ProtectedRoute>
                }
              />
              <Route
                path="/profile"
                element={
                  <ProtectedRoute>
                    <Profile />
                  </ProtectedRoute>
                }
              />
              <Route path="*" element={<Placeholder title="Page Not Found" />} />
            </Routes>
          </main>
          <Footer />
        </div>
      </BrowserRouter>
    </AuthProvider>
  );
}

export default App;
