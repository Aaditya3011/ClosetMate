import { useEffect, useState } from 'react';
import { Link, useNavigate, useParams } from 'react-router-dom';
import { api } from '../api/api';
import { useAuth } from '../context/AuthContext';
import ClothingForm from '../components/ClothingForm';
import LoadingSpinner from '../components/LoadingSpinner';
import AlertMessage from '../components/AlertMessage';

function EditClothing() {
  const { token } = useAuth();
  const { id } = useParams();
  const navigate = useNavigate();

  const [item, setItem] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [submitting, setSubmitting] = useState(false);

  useEffect(() => {
    const load = async () => {
      try {
        const data = await api.get(`/clothes/${id}`, token);
        setItem(data.clothing);
      } catch (err) {
        setError(err.message);
      } finally {
        setLoading(false);
      }
    };
    load();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [id]);

  const handleSubmit = async (values) => {
    setSubmitting(true);
    try {
      const data = await api.put(`/clothes/${id}`, values, token);
      navigate('/closet', { state: { toast: data.message } });
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="container py-4 py-lg-5">
      <div className="mb-4">
        <Link to="/closet" className="cm-link small">
          <i className="bi bi-arrow-left me-1"></i>Back to My Closet
        </Link>
        <h1 className="fw-bold mt-2 mb-1">Edit Clothing</h1>
        <p className="text-muted mb-0">Update the details of this item.</p>
      </div>

      {loading ? (
        <LoadingSpinner message="Loading item..." />
      ) : error ? (
        <AlertMessage type="danger" message={error} />
      ) : (
        <div className="cm-form-card">
          <ClothingForm
            initialValues={item}
            onSubmit={handleSubmit}
            submitLabel="Save Changes"
            submitting={submitting}
          />
        </div>
      )}
    </div>
  );
}

export default EditClothing;
