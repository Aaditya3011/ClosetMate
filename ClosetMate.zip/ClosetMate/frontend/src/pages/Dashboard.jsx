import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { api } from '../api/api';
import { useAuth } from '../context/AuthContext';
import LoadingSpinner from '../components/LoadingSpinner';
import AlertMessage from '../components/AlertMessage';
import EmptyState from '../components/EmptyState';

function StatCard({ icon, label, value, accent }) {
  return (
    <div className="col-6 col-lg-3">
      <div className="cm-stat-card card h-100">
        <div className="card-body d-flex align-items-center gap-3">
          <div className={`cm-stat-icon ${accent}`}>
            <i className={`bi ${icon}`}></i>
          </div>
          <div>
            <div className="cm-stat-value">{value}</div>
            <div className="cm-stat-label">{label}</div>
          </div>
        </div>
      </div>
    </div>
  );
}

function Breakdown({ title, rows }) {
  const max = Math.max(...rows.map((r) => r.count), 1);
  return (
    <div className="cm-panel h-100">
      <h6 className="fw-semibold mb-3">{title}</h6>
      {rows.length === 0 ? (
        <p className="text-muted small mb-0">No data yet.</p>
      ) : (
        rows.map((r) => (
          <div className="mb-3" key={r._id || 'unknown'}>
            <div className="d-flex justify-content-between small mb-1">
              <span>{r._id || 'Not set'}</span>
              <span className="text-muted">{r.count}</span>
            </div>
            <div className="cm-bar">
              <div
                className="cm-bar-fill"
                style={{ width: `${(r.count / max) * 100}%` }}
              ></div>
            </div>
          </div>
        ))
      )}
    </div>
  );
}

function Dashboard() {
  const { user, token } = useAuth();
  const [stats, setStats] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  useEffect(() => {
    const load = async () => {
      try {
        const data = await api.get('/clothes/stats', token);
        setStats(data.stats);
      } catch (err) {
        setError(err.message);
      } finally {
        setLoading(false);
      }
    };
    load();
  }, [token]);

  if (loading) return <LoadingSpinner message="Loading your dashboard..." />;

  return (
    <div className="container py-4 py-lg-5">
      <div className="d-flex flex-wrap justify-content-between align-items-center gap-3 mb-4">
        <div>
          <h1 className="fw-bold mb-1">
            Welcome back{user?.name ? `, ${user.name.split(' ')[0]}` : ''}
          </h1>
          <p className="text-muted mb-0">
            Here is a snapshot of your wardrobe.
          </p>
        </div>
        <div className="d-flex gap-2">
          <Link to="/closet/add" className="btn cm-btn-dark">
            <i className="bi bi-plus-lg me-1"></i>Add Clothing
          </Link>
          <Link to="/closet" className="btn cm-btn-outline">
            <i className="bi bi-grid me-1"></i>My Closet
          </Link>
        </div>
      </div>

      {error && <AlertMessage type="danger" message={error} />}

      {stats && stats.totalItems === 0 ? (
        <EmptyState
          icon="bi-bag-heart"
          title="Your closet is empty"
          text="Add your first item to unlock your dashboard insights."
          actionLabel="Add Your First Clothing Item"
          actionTo="/closet/add"
        />
      ) : (
        stats && (
          <>
            <div className="row g-3 mb-4">
              <StatCard
                icon="bi-collection"
                label="Total Items"
                value={stats.totalItems}
                accent="cm-accent-brown"
              />
              <StatCard
                icon="bi-heart-fill"
                label="Favorites"
                value={stats.favorites}
                accent="cm-accent-red"
              />
              <StatCard
                icon="bi-check2-circle"
                label="Times Worn"
                value={stats.totalWorn}
                accent="cm-accent-green"
              />
              <StatCard
                icon="bi-tags"
                label="Categories"
                value={stats.totalCategories}
                accent="cm-accent-blue"
              />
            </div>

            <div className="row g-3 mb-4">
              <div className="col-12 col-lg-6">
                <Breakdown title="By Category" rows={stats.byCategory} />
              </div>
              <div className="col-12 col-lg-6">
                <Breakdown title="By Season" rows={stats.bySeason} />
              </div>
            </div>

            <div className="row g-3">
              <div className="col-12 col-lg-6">
                <div className="cm-panel h-100">
                  <h6 className="fw-semibold mb-3">
                    <i className="bi bi-trophy me-1"></i>Most Worn
                  </h6>
                  {stats.mostWorn.length === 0 ? (
                    <p className="text-muted small mb-0">
                      Nothing marked as worn yet.
                    </p>
                  ) : (
                    <ul className="list-unstyled mb-0">
                      {stats.mostWorn.map((item) => (
                        <li
                          key={item._id}
                          className="d-flex justify-content-between align-items-center py-2 border-bottom"
                        >
                          <Link
                            to={`/closet/edit/${item._id}`}
                            className="text-decoration-none text-dark text-truncate"
                          >
                            {item.name}
                          </Link>
                          <span className="badge cm-badge ms-2">
                            {item.timesWorn}{' '}
                            {item.timesWorn === 1 ? 'wear' : 'wears'}
                          </span>
                        </li>
                      ))}
                    </ul>
                  )}
                </div>
              </div>

              <div className="col-12 col-lg-6">
                <div className="cm-panel h-100">
                  <h6 className="fw-semibold mb-3">
                    <i className="bi bi-clock-history me-1"></i>Recently Added
                  </h6>
                  {stats.recent.length === 0 ? (
                    <p className="text-muted small mb-0">No items yet.</p>
                  ) : (
                    <div className="row g-2">
                      {stats.recent.map((item) => (
                        <div className="col-3" key={item._id}>
                          <Link
                            to={`/closet/edit/${item._id}`}
                            className="cm-recent-tile"
                            title={item.name}
                          >
                            {item.image ? (
                              <img src={item.image} alt={item.name} />
                            ) : (
                              <i className="bi bi-image"></i>
                            )}
                          </Link>
                          <div className="small text-truncate mt-1">
                            {item.name}
                          </div>
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              </div>
            </div>
          </>
        )
      )}
    </div>
  );
}

export default Dashboard;
