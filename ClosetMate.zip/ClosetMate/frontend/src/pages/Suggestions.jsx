import { useEffect, useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { api } from '../api/api';
import { useAuth } from '../context/AuthContext';
import LoadingSpinner from '../components/LoadingSpinner';
import AlertMessage from '../components/AlertMessage';

function SuggestionCard({ suggestion, index, occasion, onSave, saving }) {
  return (
    <div className="cm-sugg-card card h-100">
      <div className="card-body">
        <div className="d-flex justify-content-between align-items-center mb-2">
          <h6 className="fw-bold mb-0">
            {occasion} Look {index + 1}
          </h6>
          <span className="badge cm-badge">
            {suggestion.items.length}{' '}
            {suggestion.items.length === 1 ? 'item' : 'items'}
          </span>
        </div>

        <div className="d-flex flex-wrap gap-2 mb-3">
          {suggestion.items.map((item) => (
            <div className="cm-sugg-item" key={item._id} title={item.name}>
              <div className="cm-sugg-tile">
                {item.image ? (
                  <img src={item.image} alt={item.name} loading="lazy" />
                ) : (
                  <i className="bi bi-image"></i>
                )}
              </div>
              <div className="cm-sugg-name text-truncate">{item.name}</div>
              <div className="cm-sugg-cat text-truncate">{item.category}</div>
            </div>
          ))}
        </div>

        <p className="text-muted small mb-3">
          <i className="bi bi-stars me-1"></i>
          {suggestion.reason}
        </p>
      </div>
      <div className="card-footer bg-white border-0 pt-0">
        <button
          type="button"
          className="btn btn-sm cm-btn-dark w-100"
          disabled={saving}
          onClick={() =>
            onSave(suggestion.items.map((i) => i._id), index + 1)
          }
        >
          <i className="bi bi-bookmark-plus me-1"></i>
          {saving ? 'Saving...' : 'Save as Outfit'}
        </button>
      </div>
    </div>
  );
}

function Suggestions() {
  const { token } = useAuth();
  const navigate = useNavigate();

  const [occasion, setOccasion] = useState('Casual');
  const [suggestions, setSuggestions] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [saving, setSaving] = useState(false);
  const [toast, setToast] = useState('');

  const fetchSuggestions = async (occ) => {
    setLoading(true);
    setError('');
    try {
      const data = await api.post('/suggestions', { occasion: occ, count: 3 }, token);
      setSuggestions(data.suggestions || []);
    } catch (err) {
      setError(err.message);
      setSuggestions([]);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchSuggestions('Casual');
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [token]);

  const handleOccasionChange = (e) => {
    const occ = e.target.value;
    setOccasion(occ);
    fetchSuggestions(occ);
  };

  const handleSave = async (itemIds, index) => {
    setSaving(true);
    setToast('');
    try {
      const data = await api.post(
        '/outfits',
        { name: `${occasion} Look ${index}`, occasion, items: itemIds },
        token
      );
      setToast(data.message);
      setTimeout(() => navigate('/outfits', { state: { toast: data.message } }), 900);
    } catch (err) {
      setError(err.message);
      setSaving(false);
    }
  };

  return (
    <div className="container py-4 py-lg-5">
      <div className="d-flex flex-wrap justify-content-between align-items-center gap-3 mb-4">
        <div>
          <h1 className="fw-bold mb-1">Outfit Suggestions</h1>
          <p className="text-muted mb-0">
            Mix your closet items into outfits, powered by your favorites.
          </p>
        </div>
      </div>

      <div className="cm-filter-bar d-flex flex-wrap align-items-end gap-3">
        <div style={{ minWidth: 220 }}>
          <label htmlFor="suggOccasion" className="form-label small text-muted mb-1">
            Occasion
          </label>
          <select
            id="suggOccasion"
            className="form-select"
            value={occasion}
            onChange={handleOccasionChange}
          >
            <option value="Casual">Casual</option>
            <option value="College">College</option>
            <option value="Formal">Formal</option>
            <option value="Party">Party</option>
            <option value="Workout">Workout</option>
            <option value="Travel">Travel</option>
          </select>
        </div>
        <button
          type="button"
          className="btn cm-btn-dark"
          onClick={() => fetchSuggestions(occasion)}
        >
          <i className="bi bi-arrow-repeat me-1"></i>Shuffle
        </button>
      </div>

      {toast && <AlertMessage type="success" message={toast} />}
      {error && (
        <AlertMessage
          type="info"
          message={
            <>
              {error}.{' '}
              <Link to="/closet/add" className="alert-link">
                Add more clothing
              </Link>{' '}
              to unlock richer suggestions.
            </>
          }
        />
      )}

      {loading ? (
        <LoadingSpinner message="Styling your suggestions..." />
      ) : (
        suggestions.length > 0 && (
          <div className="row g-4">
            {suggestions.map((suggestion, index) => (
              <div className="col-12 col-md-6 col-xl-4" key={suggestion._id}>
                <SuggestionCard
                  suggestion={suggestion}
                  index={index}
                  occasion={occasion}
                  onSave={handleSave}
                  saving={saving}
                />
              </div>
            ))}
          </div>
        )
      )}
    </div>
  );
}

export default Suggestions;