import { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { api } from '../api/api';
import { useAuth } from '../context/AuthContext';
import ClothingForm from '../components/ClothingForm';

function AddClothing() {
  const { token } = useAuth();
  const navigate = useNavigate();
  const [submitting, setSubmitting] = useState(false);

  const handleSubmit = async (values) => {
    setSubmitting(true);
    try {
      const data = await api.post('/clothes', values, token);
      navigate('/closet', { state: { toast: data.message } });
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="container py-4 py-lg-5">
      <div className="mb-4">
        <Link to="/closet" className="cm-link small">
          <i className="bi bi-arrow-left me-1"></i>Back to My Closet
        </Link>
        <h1 className="fw-bold mt-2 mb-1">Add Clothing</h1>
        <p className="text-muted mb-0">Add a new piece to your wardrobe.</p>
      </div>

      <div className="cm-form-card">
        <ClothingForm
          onSubmit={handleSubmit}
          submitLabel="Add to Closet"
          submitting={submitting}
        />
      </div>
    </div>
  );
}

export default AddClothing;
