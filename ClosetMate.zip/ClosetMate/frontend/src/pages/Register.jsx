import { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import { USER_GENDERS } from '../constants/options';
import AlertMessage from '../components/AlertMessage';

function Register() {
  const { register } = useAuth();
  const navigate = useNavigate();

  const [form, setForm] = useState({
    name: '',
    email: '',
    password: '',
    confirmPassword: '',
    gender: 'Other',
  });
  const [errors, setErrors] = useState({});
  const [apiError, setApiError] = useState('');
  const [submitting, setSubmitting] = useState(false);

  const handleChange = (e) =>
    setForm({ ...form, [e.target.name]: e.target.value });

  const validate = () => {
    const next = {};
    if (!form.name.trim()) next.name = 'Full name is required';
    if (!form.email.trim()) next.email = 'Email is required';
    else if (!/^\S+@\S+\.\S+$/.test(form.email))
      next.email = 'Please enter a valid email address';
    if (!form.password) next.password = 'Password is required';
    else if (form.password.length < 6)
      next.password = 'Password must be at least 6 characters';
    if (form.confirmPassword !== form.password)
      next.confirmPassword = 'Passwords do not match';
    setErrors(next);
    return Object.keys(next).length === 0;
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setApiError('');
    if (!validate()) return;

    setSubmitting(true);
    try {
      await register(
        form.name.trim(),
        form.email.trim(),
        form.password,
        form.gender
      );
      navigate('/dashboard');
    } catch (err) {
      setApiError(err.message);
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="cm-auth-page">
      <div className="cm-auth-card">
        <div className="text-center mb-4">
          <h2 className="fw-bold mb-1">Create your account</h2>
          <p className="text-muted mb-0">Start organizing your wardrobe</p>
        </div>

        {apiError && <AlertMessage type="danger" message={apiError} />}

        <form onSubmit={handleSubmit} noValidate>
          <div className="mb-3">
            <label className="form-label" htmlFor="name">
              Full Name
            </label>
            <input
              id="name"
              name="name"
              type="text"
              className={'form-control' + (errors.name ? ' is-invalid' : '')}
              placeholder="Your name"
              value={form.name}
              onChange={handleChange}
            />
            {errors.name && (
              <div className="invalid-feedback">{errors.name}</div>
            )}
          </div>

          <div className="mb-3">
            <label className="form-label" htmlFor="email">
              Email
            </label>
            <input
              id="email"
              name="email"
              type="email"
              className={'form-control' + (errors.email ? ' is-invalid' : '')}
              placeholder="you@example.com"
              value={form.email}
              onChange={handleChange}
            />
            {errors.email && (
              <div className="invalid-feedback">{errors.email}</div>
            )}
          </div>

          <div className="row">
            <div className="col-sm-6 mb-3">
              <label className="form-label" htmlFor="password">
                Password
              </label>
              <input
                id="password"
                name="password"
                type="password"
                className={
                  'form-control' + (errors.password ? ' is-invalid' : '')
                }
                placeholder="Min 6 characters"
                value={form.password}
                onChange={handleChange}
              />
              {errors.password && (
                <div className="invalid-feedback">{errors.password}</div>
              )}
            </div>

            <div className="col-sm-6 mb-3">
              <label className="form-label" htmlFor="confirmPassword">
                Confirm Password
              </label>
              <input
                id="confirmPassword"
                name="confirmPassword"
                type="password"
                className={
                  'form-control' +
                  (errors.confirmPassword ? ' is-invalid' : '')
                }
                placeholder="Repeat password"
                value={form.confirmPassword}
                onChange={handleChange}
              />
              {errors.confirmPassword && (
                <div className="invalid-feedback">
                  {errors.confirmPassword}
                </div>
              )}
            </div>
          </div>

          <div className="mb-3">
            <label className="form-label" htmlFor="gender">
              Gender (used for outfit suggestions)
            </label>
            <select
              id="gender"
              name="gender"
              className="form-select"
              value={form.gender}
              onChange={handleChange}
            >
              {USER_GENDERS.map((g) => (
                <option key={g} value={g}>
                  {g}
                </option>
              ))}
            </select>
          </div>

          <button
            type="submit"
            className="btn cm-btn-dark w-100 py-2"
            disabled={submitting}
          >
            {submitting ? (
              <>
                <span className="spinner-border spinner-border-sm me-2"></span>
                Creating account...
              </>
            ) : (
              'Create Account'
            )}
          </button>
        </form>

        <p className="text-center text-muted mt-4 mb-0">
          Already have an account?{' '}
          <Link to="/login" className="cm-link">
            Login
          </Link>
        </p>
      </div>
    </div>
  );
}

export default Register;
