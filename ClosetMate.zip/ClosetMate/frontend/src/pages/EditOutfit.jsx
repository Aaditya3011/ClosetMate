import { useEffect, useState } from 'react';
import { Link, useNavigate, useParams } from 'react-router-dom';
import { api } from '../api/api';
import { useAuth } from '../context/AuthContext';
import OutfitForm from '../components/OutfitForm';
import AlertMessage from '../components/AlertMessage';
import LoadingSpinner from '../components/LoadingSpinner';

function EditOutfit() {
  const { id } = useParams();
  const { token } = useAuth();
  const navigate = useNavigate();

  const [outfit, setOutfit] = useState(null);
  const [clothingItems, setClothingItems] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  useEffect(() => {
    const load = async () => {
      try {
        const [outfitData, clothesData] = await Promise.all([
          api.get(`/outfits/${id}`, token),
          api.get('/clothes', token),
        ]);
        setOutfit(outfitData.outfit);
        setClothingItems(clothesData.clothes || []);
      } catch (err) {
        setError(err.message);
      } finally {
        setLoading(false);
      }
    };
    load();
  }, [id, token]);

  const handleSubmit = async (payload) => {
    const data = await api.put(`/outfits/${id}`, payload, token);
    navigate('/outfits', {
      state: { toast: data.message },
    });
  };

  if (loading) return <LoadingSpinner message="Loading outfit..." />;

  return (
    <div className="container py-4 py-lg-5" style={{ maxWidth: 920 }}>
      <div className="d-flex align-items-center gap-2 mb-4">
        <Link to="/outfits" className="btn btn-sm btn-light border">
          <i className="bi bi-arrow-left"></i>
        </Link>
        <h1 className="fw-bold mb-0">Edit Outfit</h1>
      </div>

      {error && <AlertMessage type="danger" message={error} />}

      {outfit && (
        <div className="cm-panel">
          <OutfitForm
            initial={outfit}
            clothingItems={clothingItems}
            loadingItems={loading}
            onSubmit={handleSubmit}
            submitLabel="Save Changes"
          />
        </div>
      )}
    </div>
  );
}

export default EditOutfit;