import { useEffect, useState } from 'react';
import { Link, useLocation } from 'react-router-dom';
import { api } from '../api/api';
import { useAuth } from '../context/AuthContext';
import ClothingGrid from '../components/ClothingGrid';
import LoadingSpinner from '../components/LoadingSpinner';
import EmptyState from '../components/EmptyState';
import AlertMessage from '../components/AlertMessage';
import ConfirmationModal from '../components/ConfirmationModal';
import SearchBar from '../components/SearchBar';
import FilterBar from '../components/FilterBar';

const DEFAULT_FILTERS = {
  search: '',
  category: '',
  color: '',
  gender: '',
  season: '',
  occasion: '',
  sort: 'newest',
  favorites: false,
};

function Closet() {
  const { token } = useAuth();
  const location = useLocation();

  const [clothes, setClothes] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [toast, setToast] = useState(location.state?.toast || '');

  const [filters, setFilters] = useState(DEFAULT_FILTERS);
  const [debouncedSearch, setDebouncedSearch] = useState('');

  const [deleteTarget, setDeleteTarget] = useState(null);
  const [deleting, setDeleting] = useState(false);

  // Debounce the search box so we don't call the API on every keystroke
  useEffect(() => {
    const t = setTimeout(() => setDebouncedSearch(filters.search), 400);
    return () => clearTimeout(t);
  }, [filters.search]);

  useEffect(() => {
    const loadClothes = async () => {
      setLoading(true);
      setError('');
      try {
        const params = new URLSearchParams();
        if (debouncedSearch) params.set('search', debouncedSearch);
        if (filters.category) params.set('category', filters.category);
        if (filters.color) params.set('color', filters.color);
        if (filters.gender) params.set('gender', filters.gender);
        if (filters.season) params.set('season', filters.season);
        if (filters.occasion) params.set('occasion', filters.occasion);
        if (filters.sort) params.set('sort', filters.sort);
        if (filters.favorites) params.set('favorite', 'true');

        const query = params.toString();
        const data = await api.get(`/clothes${query ? `?${query}` : ''}`, token);
        setClothes(data.clothes || []);
      } catch (err) {
        setError(err.message);
      } finally {
        setLoading(false);
      }
    };
    loadClothes();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [
    debouncedSearch,
    filters.category,
    filters.color,
    filters.gender,
    filters.season,
    filters.occasion,
    filters.sort,
    filters.favorites,
  ]);

  const handleFilterChange = (name, value) =>
    setFilters((prev) => ({ ...prev, [name]: value }));

  const clearFilters = () => setFilters(DEFAULT_FILTERS);

  const replaceItem = (updated) =>
    setClothes((prev) =>
      prev.map((c) => (c._id === updated._id ? updated : c))
    );

  const handleToggleFavorite = async (item) => {
    try {
      const data = await api.patch(`/clothes/${item._id}/favorite`, null, token);
      // If viewing favorites only and it was unfavorited, remove it from view
      if (filters.favorites && !data.clothing.isFavorite) {
        setClothes((prev) => prev.filter((c) => c._id !== item._id));
      } else {
        replaceItem(data.clothing);
      }
    } catch (err) {
      setError(err.message);
    }
  };

  const handleMarkWorn = async (item) => {
    try {
      const data = await api.patch(`/clothes/${item._id}/worn`, null, token);
      replaceItem(data.clothing);
    } catch (err) {
      setError(err.message);
    }
  };

  const handleDelete = async () => {
    if (!deleteTarget) return;
    setDeleting(true);
    try {
      await api.del(`/clothes/${deleteTarget._id}`, token);
      setClothes((prev) => prev.filter((c) => c._id !== deleteTarget._id));
      setDeleteTarget(null);
      setToast('Clothing item deleted successfully');
    } catch (err) {
      setError(err.message);
      setDeleteTarget(null);
    } finally {
      setDeleting(false);
    }
  };

  const hasActiveFilters =
    debouncedSearch ||
    filters.category ||
    filters.color ||
    filters.gender ||
    filters.season ||
    filters.occasion ||
    filters.favorites;

  return (
    <div className="container py-4 py-lg-5">
      <div className="d-flex flex-wrap justify-content-between align-items-center gap-3 mb-4">
        <div>
          <h1 className="fw-bold mb-1">My Closet</h1>
          <p className="text-muted mb-0">
            {loading ? 'Loading your closet...' : `${clothes.length} item(s)`}
          </p>
        </div>
        <Link to="/closet/add" className="btn cm-btn-dark px-4">
          <i className="bi bi-plus-lg me-1"></i>Add Clothing
        </Link>
      </div>

      <div className="mb-3">
        <SearchBar
          value={filters.search}
          onChange={(v) => handleFilterChange('search', v)}
          placeholder="Search by name, brand or color..."
        />
      </div>

      <FilterBar
        filters={filters}
        onChange={handleFilterChange}
        onClear={clearFilters}
      />

      {toast && <AlertMessage type="success" message={toast} />}
      {error && <AlertMessage type="danger" message={error} />}

      {loading ? (
        <LoadingSpinner message="Loading your closet..." />
      ) : clothes.length === 0 ? (
        hasActiveFilters ? (
          <EmptyState
            icon="bi-search"
            title="No items match your filters"
            text="Try changing or clearing the filters to see more."
          />
        ) : (
          <EmptyState
            icon="bi-bag-heart"
            title="Your closet is empty"
            text="Start building your digital wardrobe today."
            actionLabel="Add Your First Clothing Item"
            actionTo="/closet/add"
          />
        )
      ) : (
        <ClothingGrid
          clothes={clothes}
          onToggleFavorite={handleToggleFavorite}
          onMarkWorn={handleMarkWorn}
          onDelete={setDeleteTarget}
        />
      )}

      <ConfirmationModal
        show={!!deleteTarget}
        title="Delete Clothing?"
        message={
          <>
            Are you sure you want to remove{' '}
            <strong>"{deleteTarget?.name}"</strong> from your closet?
          </>
        }
        confirmLabel="Delete"
        loading={deleting}
        onConfirm={handleDelete}
        onCancel={() => setDeleteTarget(null)}
      />
    </div>
  );
}

export default Closet;
