import { Link } from 'react-router-dom'

const features = [
  {
    icon: 'bi-folder2',
    title: 'Organize',
    text: 'Keep your entire wardrobe digitally organized.',
  },
  {
    icon: 'bi-palette',
    title: 'Create Outfits',
    text: 'Combine your favorite pieces and save complete looks.',
  },
  {
    icon: 'bi-lightbulb',
    title: 'Smart Suggestions',
    text: 'Get outfit suggestions based on occasion and season.',
  },
  {
    icon: 'bi-graph-up',
    title: 'Track Your Style',
    text: 'See which clothes you wear most and which ones are forgotten.',
  },
]

function Landing() {
  return (
    <>
      {/* Hero */}
      <section className="cm-hero">
        <div className="container">
          <div className="row align-items-center g-4">
            <div className="col-lg-6 text-center text-lg-start">
              <span className="cm-pill mb-3 d-inline-flex">
                <i className="bi bi-stars me-2"></i>Personal Wardrobe Manager
              </span>
              <h1 className="cm-hero-title">
                Your Wardrobe,
                <br />
                <span className="cm-accent">Organized.</span>
              </h1>
              <p className="cm-hero-subtitle">
                Organize your closet, create outfits, and discover what to wear.
              </p>
              <div className="d-flex gap-3 justify-content-center justify-content-lg-start mt-4">
                <Link to="/register" className="btn cm-btn-dark px-4 py-2">
                  Get Started
                </Link>
                <Link to="/login" className="btn cm-btn-outline px-4 py-2">
                  Login
                </Link>
              </div>
            </div>

            {/* Wardrobe composition */}
            <div className="col-lg-6 ps-lg-4">
              <div className="cm-closet-visual mx-auto">
                <div className="row g-3">
                  <div className="col-6">
                    <div className="cm-visual-card">
                      <i className="bi bi-layers"></i>
                      <span>Tops</span>
                    </div>
                  </div>
                  <div className="col-6">
                    <div className="cm-visual-card cm-visual-pink">
                      <i className="bi bi-flower2"></i>
                      <span>Dresses</span>
                    </div>
                  </div>
                  <div className="col-6">
                    <div className="cm-visual-card cm-visual-beige">
                      <i className="bi bi-handbag"></i>
                      <span>Accessories</span>
                    </div>
                  </div>
                  <div className="col-6">
                    <div className="cm-visual-card cm-visual-brown">
                      <i className="bi bi-star"></i>
                      <span>Outfits</span>
                    </div>
                  </div>
                </div>
                <div className="cm-visual-badge">
                  <i className="bi bi-heart-fill"></i>
                  <span>All your style in one place</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Features */}
      <section className="cm-features py-5">
        <div className="container">
          <div className="text-center mb-5">
            <h2 className="fw-bold">Everything your wardrobe needs</h2>
            <p className="text-muted">
              Simple tools to keep your style on track.
            </p>
          </div>
          <div className="row g-4">
            {features.map((f) => (
              <div className="col-sm-6 col-lg-3" key={f.title}>
                <div className="cm-feature-card h-100">
                  <div className="cm-feature-icon">
                    <i className={`bi ${f.icon}`}></i>
                  </div>
                  <h5 className="fw-semibold mt-3 mb-2">{f.title}</h5>
                  <p className="text-muted mb-0 small">{f.text}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Call to action */}
      <section className="cm-cta mb-5">
        <div className="container">
          <div className="cm-cta-box text-center p-4 p-md-5">
            <h3 className="fw-bold">Ready to organize your closet?</h3>
            <p className="text-muted mb-4">
              Create your free account and start building your digital wardrobe.
            </p>
            <Link to="/register" className="btn cm-btn-dark px-5 py-2">
              Get Started — It's Free
            </Link>
          </div>
        </div>
      </section>
    </>
  )
}

export default Landing
