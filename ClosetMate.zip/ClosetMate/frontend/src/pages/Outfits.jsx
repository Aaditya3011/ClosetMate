import { useEffect, useState } from 'react';
import { Link, useLocation } from 'react-router-dom';
import { api } from '../api/api';
import { useAuth } from '../context/AuthContext';
import OutfitCard from '../components/OutfitCard';
import LoadingSpinner from '../components/LoadingSpinner';
import EmptyState from '../components/EmptyState';
import AlertMessage from '../components/AlertMessage';
import ConfirmationModal from '../components/ConfirmationModal';

function Outfits() {
  const { token } = useAuth();
  const location = useLocation();

  const [outfits, setOutfits] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [toast, setToast] = useState(location.state?.toast || '');

  const [deleteTarget, setDeleteTarget] = useState(null);
  const [deleting, setDeleting] = useState(false);

  useEffect(() => {
    const load = async () => {
      try {
        const data = await api.get('/outfits', token);
        setOutfits(data.outfits || []);
      } catch (err) {
        setError(err.message);
      } finally {
        setLoading(false);
      }
    };
    load();
  }, [token]);

  const handleDelete = async () => {
    if (!deleteTarget) return;
    setDeleting(true);
    try {
      await api.del(`/outfits/${deleteTarget._id}`, token);
      setOutfits((prev) => prev.filter((o) => o._id !== deleteTarget._id));
      setDeleteTarget(null);
      setToast('Outfit deleted successfully');
    } catch (err) {
      setError(err.message);
      setDeleteTarget(null);
    } finally {
      setDeleting(false);
    }
  };

  return (
    <div className="container py-4 py-lg-5">
      <div className="d-flex flex-wrap justify-content-between align-items-center gap-3 mb-4">
        <div>
          <h1 className="fw-bold mb-1">My Outfits</h1>
          <p className="text-muted mb-0">
            {loading ? 'Loading your outfits...' : `${outfits.length} outfit(s)`}
          </p>
        </div>
        <Link to="/outfits/new" className="btn cm-btn-dark px-4">
          <i className="bi bi-plus-lg me-1"></i>Create Outfit
        </Link>
      </div>

      {toast && <AlertMessage type="success" message={toast} />}
      {error && <AlertMessage type="danger" message={error} />}

      {loading ? (
        <LoadingSpinner message="Loading your outfits..." />
      ) : outfits.length === 0 ? (
        <EmptyState
          icon="bi-share"
          title="No outfits yet"
          text="Combine your closet items into outfits you can mix and match."
          actionLabel="Create Your First Outfit"
          actionTo="/outfits/new"
        />
      ) : (
        <div className="row g-4">
          {outfits.map((outfit) => (
            <div className="col-12 col-sm-6 col-lg-4" key={outfit._id}>
              <OutfitCard outfit={outfit} onDelete={setDeleteTarget} />
            </div>
          ))}
        </div>
      )}

      <ConfirmationModal
        show={!!deleteTarget}
        title="Delete Outfit?"
        message={
          <>
            Are you sure you want to remove{' '}
            <strong>"{deleteTarget?.name}"</strong>? Your clothing items will be
            kept.
          </>
        }
        confirmLabel="Delete"
        loading={deleting}
        onConfirm={handleDelete}
        onCancel={() => setDeleteTarget(null)}
      />
    </div>
  );
}

export default Outfits;