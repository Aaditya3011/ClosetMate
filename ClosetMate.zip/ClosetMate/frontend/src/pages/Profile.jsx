import { useState } from 'react';
import { api } from '../api/api';
import { useAuth } from '../context/AuthContext';
import { USER_GENDERS } from '../constants/options';
import AlertMessage from '../components/AlertMessage';

function Profile() {
  const { user, token, updateUser } = useAuth();

  const [name, setName] = useState(user?.name || '');
  const [email, setEmail] = useState(user?.email || '');
  const [image, setImage] = useState(user?.profileImage || '');
  const [gender, setGender] = useState(user?.gender || 'Other');

  const [currentPassword, setCurrentPassword] = useState('');
  const [newPassword, setNewPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');

  const [savingProfile, setSavingProfile] = useState(false);
  const [savingPassword, setSavingPassword] = useState(false);
  const [profileMsg, setProfileMsg] = useState('');
  const [passMsg, setPassMsg] = useState('');
  const [errorMsg, setErrorMsg] = useState('');

  const initials = name.trim()?.charAt(0)?.toUpperCase() || 'U';

  const handleSaveProfile = async (e) => {
    e.preventDefault();
    setSavingProfile(true);
    setProfileMsg('');
    setErrorMsg('');
    try {
      const data = await api.put(
        '/auth/profile',
        { name, email, profileImage: image, gender },
        token
      );
      updateUser(data.user);
      setProfileMsg(data.message);
    } catch (err) {
      setErrorMsg(err.message);
    } finally {
      setSavingProfile(false);
    }
  };

  const handleChangePassword = async (e) => {
    e.preventDefault();
    setPassMsg('');
    setErrorMsg('');
    if (newPassword !== confirmPassword) {
      setErrorMsg('New password and confirmation do not match');
      return;
    }
    setSavingPassword(true);
    try {
      const data = await api.put(
        '/auth/change-password',
        { currentPassword, newPassword },
        token
      );
      setPassMsg(data.message);
      setCurrentPassword('');
      setNewPassword('');
      setConfirmPassword('');
    } catch (err) {
      setErrorMsg(err.message);
    } finally {
      setSavingPassword(false);
    }
  };

  const joined = user?.createdAt
    ? new Date(user.createdAt).toLocaleDateString(undefined, {
        year: 'numeric',
        month: 'long',
      })
    : '';

  return (
    <div className="container py-4 py-lg-5">
      <h1 className="fw-bold mb-4">
        <i className="bi bi-person-circle me-2"></i>Profile
      </h1>

      <div className="row g-4">
        <div className="col-12 col-lg-4">
          <div className="cm-panel text-center">
            <div className="cm-avatar-lg mx-auto mb-3">
              {image ? (
                <img src={image} alt="Profile" />
              ) : (
                <span>{initials}</span>
              )}
            </div>
            <h5 className="mb-0">{user?.name}</h5>
            <p className="text-muted small mb-2">{user?.email}</p>
            {joined && (
              <p className="text-muted small mb-0">
                Member since {joined}
              </p>
            )}
          </div>
        </div>

        <div className="col-12 col-lg-8">
          {profileMsg && <AlertMessage type="success" message={profileMsg} />}
          {passMsg && <AlertMessage type="success" message={passMsg} />}
          {errorMsg && <AlertMessage type="danger" message={errorMsg} />}

          <div className="cm-panel mb-4">
            <h6 className="fw-semibold mb-3">Account Details</h6>
            <form onSubmit={handleSaveProfile}>
              <div className="mb-3">
                <label htmlFor="pName" className="form-label">
                  Name
                </label>
                <input
                  id="pName"
                  type="text"
                  className="form-control cm-input"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  required
                />
              </div>
              <div className="mb-3">
                <label htmlFor="pEmail" className="form-label">
                  Email
                </label>
                <input
                  id="pEmail"
                  type="email"
                  className="form-control cm-input"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  required
                />
              </div>
              <div className="mb-3">
                <label htmlFor="pImage" className="form-label">
                  Profile image URL (optional)
                </label>
                <input
                  id="pImage"
                  type="url"
                  className="form-control cm-input"
                  value={image}
                  placeholder="https://example.com/my-photo.jpg"
                  onChange={(e) => setImage(e.target.value)}
                />
              </div>
              <div className="mb-3">
                <label htmlFor="pGender" className="form-label">
                  Gender (used for outfit suggestions)
                </label>
                <select
                  id="pGender"
                  className="form-select cm-input"
                  value={gender}
                  onChange={(e) => setGender(e.target.value)}
                >
                  {USER_GENDERS.map((g) => (
                    <option key={g} value={g}>
                      {g}
                    </option>
                  ))}
                </select>
              </div>
              <button
                type="submit"
                className="btn cm-btn-dark"
                disabled={savingProfile}
              >
                {savingProfile ? 'Saving...' : 'Save Changes'}
              </button>
            </form>
          </div>

          <div className="cm-panel">
            <h6 className="fw-semibold mb-3">Change Password</h6>
            <form onSubmit={handleChangePassword}>
              <div className="mb-3">
                <label htmlFor="curPw" className="form-label">
                  Current password
                </label>
                <input
                  id="curPw"
                  type="password"
                  className="form-control cm-input"
                  value={currentPassword}
                  onChange={(e) => setCurrentPassword(e.target.value)}
                  required
                  autoComplete="current-password"
                />
              </div>
              <div className="row g-3">
                <div className="col-12 col-md-6">
                  <label htmlFor="newPw" className="form-label">
                    New password
                  </label>
                  <input
                    id="newPw"
                    type="password"
                    className="form-control cm-input"
                    value={newPassword}
                    onChange={(e) => setNewPassword(e.target.value)}
                    required
                    minLength={6}
                    autoComplete="new-password"
                  />
                </div>
                <div className="col-12 col-md-6">
                  <label htmlFor="confPw" className="form-label">
                    Confirm new password
                  </label>
                  <input
                    id="confPw"
                    type="password"
                    className="form-control cm-input"
                    value={confirmPassword}
                    onChange={(e) => setConfirmPassword(e.target.value)}
                    required
                    minLength={6}
                    autoComplete="new-password"
                  />
                </div>
              </div>
              <button
                type="submit"
                className="btn cm-btn-outline mt-3"
                disabled={savingPassword}
              >
                {savingPassword ? 'Updating...' : 'Update Password'}
              </button>
            </form>
          </div>
        </div>
      </div>
    </div>
  );
}

export default Profile;