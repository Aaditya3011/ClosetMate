import { useEffect, useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { api } from '../api/api';
import { useAuth } from '../context/AuthContext';
import OutfitForm from '../components/OutfitForm';
import AlertMessage from '../components/AlertMessage';

function CreateOutfit() {
  const { token } = useAuth();
  const navigate = useNavigate();

  const [clothingItems, setClothingItems] = useState([]);
  const [loadingItems, setLoadingItems] = useState(true);
  const [error, setError] = useState('');

  useEffect(() => {
    const load = async () => {
      try {
        const data = await api.get('/clothes', token);
        setClothingItems(data.clothes || []);
      } catch (err) {
        setError(err.message);
      } finally {
        setLoadingItems(false);
      }
    };
    load();
  }, [token]);

  const handleSubmit = async (payload) => {
    const data = await api.post('/outfits', payload, token);
    navigate('/outfits', {
      state: { toast: data.message },
    });
  };

  return (
    <div className="container py-4 py-lg-5" style={{ maxWidth: 920 }}>
      <div className="d-flex align-items-center gap-2 mb-4">
        <Link to="/outfits" className="btn btn-sm btn-light border">
          <i className="bi bi-arrow-left"></i>
        </Link>
        <h1 className="fw-bold mb-0">Create Your Outfit</h1>
      </div>

      {error && <AlertMessage type="danger" message={error} />}

      <div className="cm-panel">
        <OutfitForm
          clothingItems={clothingItems}
          loadingItems={loadingItems}
          onSubmit={handleSubmit}
          submitLabel="Create Outfit"
        />
      </div>
    </div>
  );
}

export default CreateOutfit;