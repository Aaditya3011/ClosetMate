// Central place for every backend call.
// The base URL comes from frontend/.env -> VITE_API_URL
const API_URL = import.meta.env.VITE_API_URL || 'http://localhost:5000/api';

async function request(method, endpoint, body, token) {
  const headers = { 'Content-Type': 'application/json' };
  if (token) {
    headers.Authorization = `Bearer ${token}`;
  }

  const res = await fetch(`${API_URL}${endpoint}`, {
    method,
    headers,
    body: body ? JSON.stringify(body) : undefined,
  });

  let data = {};
  try {
    data = await res.json();
  } catch {
    data = {};
  }

  if (!res.ok) {
    // Use the backend's friendly message when available
    throw new Error(data.message || `Request failed (${res.status})`);
  }

  return data;
}

export const api = {
  get: (endpoint, token) => request('GET', endpoint, null, token),
  post: (endpoint, body, token) => request('POST', endpoint, body, token),
  put: (endpoint, body, token) => request('PUT', endpoint, body, token),
  patch: (endpoint, body, token) => request('PATCH', endpoint, body, token),
  del: (endpoint, token) => request('DELETE', endpoint, null, token),
};
