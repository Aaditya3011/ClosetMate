const express = require('express');
const cors = require('cors');
require('dotenv').config();

const connectDB = require('./config/db');
const authRoutes = require('./routes/authRoutes');
const clothingRoutes = require('./routes/clothingRoutes');
const outfitRoutes = require('./routes/outfitRoutes');
const suggestionRoutes = require('./routes/suggestionRoutes');
const { notFound, errorHandler } = require('./middleware/errorMiddleware');

const app = express();

// Allow only our React development app to talk to this API
const corsOptions = {
  origin: process.env.CLIENT_URL || 'http://localhost:5173',
};
app.use(cors(corsOptions));

// Parse JSON request bodies
app.use(express.json());

// Health check
app.get('/api/health', (req, res) => {
  res.status(200).json({
    success: true,
    message: 'ClosetMate API is running',
  });
});

// Routes
app.use('/api/auth', authRoutes);
app.use('/api/clothes', clothingRoutes);
app.use('/api/outfits', outfitRoutes);
app.use('/api/suggestions', suggestionRoutes);

// 404 + error handling (must be last)
app.use(notFound);
app.use(errorHandler);

const PORT = process.env.PORT || 5000;

// Connect to MongoDB Atlas first, then start accepting requests
const startServer = async () => {
  await connectDB();
  app.listen(PORT, () => {
    console.log(`Server running on port ${PORT}`);
  });
};

startServer();

