const mongoose = require('mongoose');

// Connect to MongoDB Atlas using the connection string in .env
const connectDB = async () => {
  try {
    if (!process.env.MONGODB_URI) {
      throw new Error('MONGODB_URI is missing. Add it to backend/.env');
    }

    const conn = await mongoose.connect(process.env.MONGODB_URI);

    console.log(`MongoDB Atlas connected successfully`);
    console.log(`Database host: ${conn.connection.host}`);
  } catch (error) {
    console.error('MongoDB Atlas connection failed:', error.message);
    console.error('');
    console.error('Common causes:');
    console.error(' 1. Wrong username or password inside MONGODB_URI');
    console.error(' 2. Your IP address is not allowed in Atlas (Network Access)');
    console.error(' 3. Special characters in the password are not URL-encoded');
    console.error(' 4. The .env file is missing or not saved in backend/');
    console.error('');
    process.exit(1);
  }
};

module.exports = connectDB;
