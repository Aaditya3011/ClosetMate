const mongoose = require('mongoose');

const clothingSchema = new mongoose.Schema(
  {
    userId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'User',
      required: true,
      index: true,
    },
    name: {
      type: String,
      required: [true, 'Clothing name is required'],
      trim: true,
    },
    category: {
      type: String,
      required: [true, 'Category is required'],
      enum: [
        'Tops',
        'Bottoms',
        'Dresses',
        'Outerwear',
        'Shoes',
        'Accessories',
      ],
    },
    type: {
      type: String,
      trim: true,
      default: '',
    },
    color: {
      type: String,
      trim: true,
      default: '',
    },
    season: {
      type: String,
      enum: ['Summer', 'Winter', 'Spring', 'Autumn', 'All Season'],
      default: 'All Season',
    },
    occasion: {
      type: String,
      enum: ['Casual', 'College', 'Formal', 'Party', 'Workout', 'Travel'],
      default: 'Casual',
    },
    image: {
      type: String,
      default: '',
    },
    brand: {
      type: String,
      trim: true,
      default: '',
    },
    size: {
      type: String,
      trim: true,
      default: '',
    },
    timesWorn: {
      type: Number,
      default: 0,
      min: 0,
    },
    isFavorite: {
      type: Boolean,
      default: false,
    },
    gender: {
      type: String,
      enum: ['Male', 'Female', 'Unisex'],
      default: 'Unisex',
    },
  },
  { timestamps: true }
);

module.exports = mongoose.model('Clothing', clothingSchema);
