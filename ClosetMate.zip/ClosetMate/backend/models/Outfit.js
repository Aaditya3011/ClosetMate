const mongoose = require('mongoose');

const outfitSchema = new mongoose.Schema(
  {
    userId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'User',
      required: true,
      index: true,
    },
    name: {
      type: String,
      required: [true, 'Outfit name is required'],
      trim: true,
      maxlength: [100, 'Name must be under 100 characters'],
    },
    // Items reference the user's clothing (populated when returned)
    items: [
      {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'Clothing',
      },
    ],
    occasion: {
      type: String,
      enum: ['Casual', 'College', 'Formal', 'Party', 'Workout', 'Travel'],
      default: 'Casual',
    },
    notes: {
      type: String,
      trim: true,
      default: '',
      maxlength: [500, 'Notes must be under 500 characters'],
    },
  },
  { timestamps: true }
);

module.exports = mongoose.model('Outfit', outfitSchema);