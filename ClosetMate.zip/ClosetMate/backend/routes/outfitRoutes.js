const express = require('express');
const {
  getOutfits,
  getOutfitById,
  createOutfit,
  updateOutfit,
  deleteOutfit,
} = require('../controllers/outfitController');
const { protect } = require('../middleware/authMiddleware');

const router = express.Router();

// Every outfit route requires a valid JWT
router.use(protect);

router.route('/').get(getOutfits).post(createOutfit);

router
  .route('/:id')
  .get(getOutfitById)
  .put(updateOutfit)
  .delete(deleteOutfit);

module.exports = router;