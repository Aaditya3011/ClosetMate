const express = require('express');
const {
  getClothes,
  getStats,
  getClothingById,
  createClothing,
  updateClothing,
  deleteClothing,
  toggleFavorite,
  markAsWorn,
} = require('../controllers/clothingController');
const { protect } = require('../middleware/authMiddleware');

const router = express.Router();

// Every clothing route requires a valid JWT
router.use(protect);

router.route('/').get(getClothes).post(createClothing);

// Must come before '/:id' so "stats" isn't treated as an id
router.get('/stats', getStats);

router
  .route('/:id')
  .get(getClothingById)
  .put(updateClothing)
  .delete(deleteClothing);

router.patch('/:id/favorite', toggleFavorite);
router.patch('/:id/worn', markAsWorn);

module.exports = router;
