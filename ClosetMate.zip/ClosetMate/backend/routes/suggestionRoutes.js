const express = require('express');
const { getSuggestions } = require('../controllers/suggestionController');
const { protect } = require('../middleware/authMiddleware');

const router = express.Router();

router.use(protect);

router.post('/', getSuggestions);

module.exports = router;