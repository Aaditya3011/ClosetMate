const Clothing = require('../models/Clothing');

const OCCASIONS = ['Casual', 'College', 'Formal', 'Party', 'Workout', 'Travel'];

const pick = (pool, index) => pool[index % pool.length];

// @route  POST /api/suggestions
// @access Private
// Body: { occasion?, count? }
// Composes outfit ideas from the user's own closet, preferring
// occasion-matched items, then favorites, then anything else.
const getSuggestions = async (req, res, next) => {
  try {
    const occasion = OCCASIONS.includes(req.body.occasion)
      ? req.body.occasion
      : 'Casual';
    const count = Math.min(Math.max(parseInt(req.body.count) || 3, 1), 6);

    const all = await Clothing.find({ userId: req.user._id });

    // Gender-aware: pick items matching the user's gender (+ unisex items).
    // Users with "Other" gender see every item.
    const userGender = req.user.gender;
    const pool =
      userGender && userGender !== 'Other'
        ? all.filter(
            (c) => c.gender === userGender || c.gender === 'Unisex'
          )
        : all;

    if (pool.length < 2) {
      res.status(400);
      throw new Error(
        userGender && userGender !== 'Other'
          ? 'Not enough clothing matching your selected gender. Add more items or update your profile.'
          : 'Add at least 2 clothing items to your closet to unlock suggestions'
      );
    }

    // Occasion matches first, favorites second, everything else last
    const matched = pool.filter((c) => c.occasion === occasion);
    const favorites = pool.filter(
      (c) => c.isFavorite && !matched.includes(c)
    );
    const rest = pool.filter(
      (c) => !matched.includes(c) && !favorites.includes(c)
    );
    const ranked = [...matched, ...favorites, ...rest];

    const byCategory = { Tops: [], Bottoms: [], Dresses: [], Shoes: [], Outerwear: [], Accessories: [] };
    for (const c of ranked) {
      if (byCategory[c.category]) byCategory[c.category].push(c);
    }
    const { Tops: tops, Bottoms: bottoms, Dresses: dresses, Shoes: shoes, Outerwear: outerwear, Accessories: accessories } = byCategory;

    // A random rotation makes every request (Shuffle) return different combos
    const maxLen = Math.max(
      tops.length,
      bottoms.length,
      dresses.length,
      shoes.length,
      outerwear.length,
      accessories.length,
      1
    );
    const start = Math.floor(Math.random() * maxLen);

    // Alternate between "dress look" and "top + bottom look" so a closet
    // with both produces a variety of outfit ideas.
    const buildLook = (k) => {
      const useDress = dresses.length > 0 && k % 3 === 0;

      let items;
      if (useDress || (dresses.length && (!tops.length || !bottoms.length))) {
        items = [pick(dresses, start + Math.floor(k / 3))];
        if (shoes.length) items.push(pick(shoes, start + Math.floor(k / 3)));
      } else if (tops.length && bottoms.length) {
        items = [pick(tops, start + k), pick(bottoms, start + k)];
        if (shoes.length) items.push(pick(shoes, start + k));
      } else {
        const a = ranked[(start + k) % ranked.length];
        let b = ranked[(start + k + 1) % ranked.length];
        if (a._id.equals(b._id)) b = ranked[(start + k + 2) % ranked.length];
        items = b ? [a, b] : [a];
      }

      if (outerwear.length && k % 2 === 0) items.push(pick(outerwear, start + k));
      if (accessories.length && k % 3 === 0) items.push(pick(accessories, start + k));
      return items;
    };

    const seen = new Set();
    const suggestions = [];
    let attempts = 0;
    let k = 0;

    while (suggestions.length < count && attempts < 60) {
      attempts += 1;
      const items = buildLook(k);

      // Visit only distinct item sets
      const key = items.map((i) => i._id).sort().join('|');
      if (!seen.has(key)) {
        seen.add(key);
        const favCount = items.filter((i) => i.isFavorite).length;
        suggestions.push({
          _id: `sugg_${suggestions.length}`,
          reason:
            favCount >= 2
              ? `Uses ${favCount} of your favorite items`
              : `${occasion} combo`,
          items,
        });
      }
      k += 1;
    }

    res.status(200).json({
      success: true,
      occasion,
      count: suggestions.length,
      suggestions,
    });
  } catch (error) {
    next(error);
  }
};

module.exports = { getSuggestions };