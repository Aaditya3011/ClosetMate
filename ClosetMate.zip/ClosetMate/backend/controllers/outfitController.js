const Outfit = require('../models/Outfit');
const Clothing = require('../models/Clothing');

// Return only clothing ids the user actually owns (deduped)
const resolveOwnedItems = async (userId, rawItems) => {
  const ids = [...new Set((Array.isArray(rawItems) ? rawItems : []).map(String))]
    .filter(Boolean);
  if (ids.length === 0) return [];

  const owned = await Clothing.find({ _id: { $in: ids }, userId });
  return owned.map((c) => c._id);
};

// @route  GET /api/outfits
// @access Private
const getOutfits = async (req, res, next) => {
  try {
    const outfits = await Outfit.find({ userId: req.user._id })
      .sort({ createdAt: -1 })
      .populate('items');
    res.status(200).json({ success: true, count: outfits.length, outfits });
  } catch (error) {
    next(error);
  }
};

// @route  GET /api/outfits/:id
// @access Private
const getOutfitById = async (req, res, next) => {
  try {
    const outfit = await Outfit.findOne({
      _id: req.params.id,
      userId: req.user._id,
    }).populate('items');
    if (!outfit) {
      res.status(404);
      throw new Error('Outfit not found');
    }
    res.status(200).json({ success: true, outfit });
  } catch (error) {
    next(error);
  }
};

// @route  POST /api/outfits
// @access Private
const createOutfit = async (req, res, next) => {
  try {
    const { name, items, occasion, notes } = req.body;

    if (!name || !name.trim()) {
      res.status(400);
      throw new Error('Outfit name is required');
    }

    const validItems = await resolveOwnedItems(req.user._id, items);

    const outfit = await Outfit.create({
      userId: req.user._id,
      name: name.trim(),
      items: validItems,
      occasion: occasion || 'Casual',
      notes: notes || '',
    });
    await outfit.populate('items');

    res.status(201).json({
      success: true,
      message: 'Outfit created successfully',
      outfit,
    });
  } catch (error) {
    next(error);
  }
};

// @route  PUT /api/outfits/:id
// @access Private
const updateOutfit = async (req, res, next) => {
  try {
    const outfit = await Outfit.findOne({
      _id: req.params.id,
      userId: req.user._id,
    });
    if (!outfit) {
      res.status(404);
      throw new Error('Outfit not found');
    }

    const { name, items, occasion, notes } = req.body;

    if (name !== undefined) {
      if (!name.trim()) {
        res.status(400);
        throw new Error('Outfit name is required');
      }
      outfit.name = name.trim();
    }
    if (items !== undefined) {
      outfit.items = await resolveOwnedItems(req.user._id, items);
    }
    if (occasion !== undefined) outfit.occasion = occasion;
    if (notes !== undefined) outfit.notes = notes;

    const updated = await outfit.save();
    await updated.populate('items');

    res.status(200).json({
      success: true,
      message: 'Outfit updated successfully',
      outfit: updated,
    });
  } catch (error) {
    next(error);
  }
};

// @route  DELETE /api/outfits/:id
// @access Private
const deleteOutfit = async (req, res, next) => {
  try {
    const outfit = await Outfit.findOne({
      _id: req.params.id,
      userId: req.user._id,
    });
    if (!outfit) {
      res.status(404);
      throw new Error('Outfit not found');
    }
    await outfit.deleteOne();
    res.status(200).json({
      success: true,
      message: 'Outfit deleted successfully',
    });
  } catch (error) {
    next(error);
  }
};

module.exports = {
  getOutfits,
  getOutfitById,
  createOutfit,
  updateOutfit,
  deleteOutfit,
};