const User = require('../models/User');
const generateToken = require('../utils/generateToken');

// @route  POST /api/auth/register
// @access Public
const registerUser = async (req, res, next) => {
  try {
    const { name, email, password, gender } = req.body;

    // Basic validation (never trust the frontend alone)
    if (!name || !email || !password) {
      res.status(400);
      throw new Error('Please fill in all fields');
    }
    if (password.length < 6) {
      res.status(400);
      throw new Error('Password must be at least 6 characters');
    }

    const userExists = await User.findOne({ email: email.toLowerCase() });
    if (userExists) {
      res.status(409);
      throw new Error('An account with this email already exists');
    }

    const user = await User.create({
      name,
      email,
      password,
      gender: gender || 'Other',
    });

    res.status(201).json({
      success: true,
      message: 'Account created successfully',
      token: generateToken(user._id),
      user: toPublicUser(user),
    });
  } catch (error) {
    next(error);
  }
};

// @route  POST /api/auth/login
// @access Public
const loginUser = async (req, res, next) => {
  try {
    const { email, password } = req.body;

    if (!email || !password) {
      res.status(400);
      throw new Error('Please enter email and password');
    }

    // password has select:false, so ask for it explicitly
    const user = await User.findOne({ email: email.toLowerCase() }).select(
      '+password'
    );

    if (!user || !(await user.matchPassword(password))) {
      res.status(401);
      throw new Error('Invalid email or password');
    }

    res.status(200).json({
      success: true,
      message: 'Logged in successfully',
      token: generateToken(user._id),
      user: toPublicUser(user),
    });
  } catch (error) {
    next(error);
  }
};

// Shape a user object for the client (never expose the password)
const toPublicUser = (user) => ({
  _id: user._id,
  name: user.name,
  email: user.email,
  profileImage: user.profileImage,
  gender: user.gender,
  createdAt: user.createdAt,
});

// @route  GET /api/auth/profile
// @access Private
const getProfile = async (req, res, next) => {
  try {
    const user = await User.findById(req.user._id);
    if (!user) {
      res.status(404);
      throw new Error('User not found');
    }
    res.status(200).json({ success: true, user: toPublicUser(user) });
  } catch (error) {
    next(error);
  }
};

// @route  PUT /api/auth/profile
// @access Private
const updateProfile = async (req, res, next) => {
  try {
    const user = await User.findById(req.user._id);
    if (!user) {
      res.status(404);
      throw new Error('User not found');
    }

    const { name, email, profileImage, gender } = req.body;

    if (name !== undefined) {
      if (!name.trim()) {
        res.status(400);
        throw new Error('Name cannot be empty');
      }
      user.name = name.trim();
    }

    if (email !== undefined && email.toLowerCase() !== user.email) {
      const exists = await User.findOne({ email: email.toLowerCase() });
      if (exists) {
        res.status(409);
        throw new Error('An account with this email already exists');
      }
      user.email = email.toLowerCase();
    }

    if (profileImage !== undefined) {
      user.profileImage = profileImage;
    }

    if (gender !== undefined) {
      user.gender = gender;
    }

    const updated = await user.save();

    res.status(200).json({
      success: true,
      message: 'Profile updated successfully',
      user: toPublicUser(updated),
    });
  } catch (error) {
    next(error);
  }
};

// @route  PUT /api/auth/change-password
// @access Private
const changePassword = async (req, res, next) => {
  try {
    const { currentPassword, newPassword } = req.body;

    if (!currentPassword || !newPassword) {
      res.status(400);
      throw new Error('Please provide your current and new password');
    }
    if (newPassword.length < 6) {
      res.status(400);
      throw new Error('New password must be at least 6 characters');
    }

    // password has select:false so request it explicitly
    const user = await User.findById(req.user._id).select('+password');
    if (!user || !(await user.matchPassword(currentPassword))) {
      res.status(401);
      throw new Error('Current password is incorrect');
    }

    user.password = newPassword;
    await user.save();

    res.status(200).json({
      success: true,
      message: 'Password updated successfully',
    });
  } catch (error) {
    next(error);
  }
};

module.exports = {
  registerUser,
  loginUser,
  getProfile,
  updateProfile,
  changePassword,
};