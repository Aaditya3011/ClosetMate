const Clothing = require('../models/Clothing');
const Outfit = require('../models/Outfit');

// Fields a user is allowed to set/edit (userId is NEVER accepted from the body)
const EDITABLE_FIELDS = [
  'name',
  'category',
  'type',
  'color',
  'season',
  'occasion',
  'image',
  'brand',
  'size',
  'gender',
];

// @route  GET /api/clothes
// @access Private
// Supports: ?search= &category= &color= &season= &occasion= &favorite=true &sort=
const getClothes = async (req, res, next) => {
  try {
    const { search, category, color, season, occasion, gender, favorite, sort } =
      req.query;

    // Always scope to the authenticated user
    const filter = { userId: req.user._id };

    if (category) filter.category = category;
    if (color) filter.color = color;
    if (season) filter.season = season;
    if (occasion) filter.occasion = occasion;
    if (gender) filter.gender = gender;
    if (favorite === 'true') filter.isFavorite = true;

    // Search name, brand or color (case-insensitive)
    if (search && search.trim()) {
      const safe = search.trim().replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
      const rx = new RegExp(safe, 'i');
      filter.$or = [{ name: rx }, { brand: rx }, { color: rx }];
    }

    const sortMap = {
      newest: { createdAt: -1 },
      oldest: { createdAt: 1 },
      mostWorn: { timesWorn: -1, createdAt: -1 },
      leastWorn: { timesWorn: 1, createdAt: -1 },
      nameAsc: { name: 1 },
      nameDesc: { name: -1 },
    };
    const sortBy = sortMap[sort] || sortMap.newest;

    const items = await Clothing.find(filter).sort(sortBy);
    res.status(200).json({ success: true, count: items.length, clothes: items });
  } catch (error) {
    next(error);
  }
};

// @route  GET /api/clothes/stats
// @access Private
// Aggregated numbers + breakdowns used by the Dashboard
const getStats = async (req, res, next) => {
  try {
    const userId = req.user._id;

    const [totalItems, favorites, wornAgg] = await Promise.all([
      Clothing.countDocuments({ userId }),
      Clothing.countDocuments({ userId, isFavorite: true }),
      Clothing.aggregate([
        { $match: { userId } },
        { $group: { _id: null, totalWorn: { $sum: '$timesWorn' } } },
      ]),
    ]);
    const totalWorn = wornAgg[0]?.totalWorn || 0;

    const groupBy = (field) =>
      Clothing.aggregate([
        { $match: { userId } },
        { $group: { _id: `$${field}`, count: { $sum: 1 } } },
        { $sort: { count: -1 } },
      ]);

    const [byCategory, bySeason, byColor, byOccasion, mostWorn, recent] =
      await Promise.all([
        groupBy('category'),
        groupBy('season'),
        groupBy('color'),
        groupBy('occasion'),
        Clothing.find({ userId, timesWorn: { $gt: 0 } })
          .sort({ timesWorn: -1 })
          .limit(5),
        Clothing.find({ userId }).sort({ createdAt: -1 }).limit(4),
      ]);

    res.status(200).json({
      success: true,
      stats: {
        totalItems,
        favorites,
        totalWorn,
        totalCategories: byCategory.length,
        byCategory,
        bySeason,
        byColor,
        byOccasion,
        mostWorn,
        recent,
      },
    });
  } catch (error) {
    next(error);
  }
};

// @route  GET /api/clothes/:id
// @access Private
const getClothingById = async (req, res, next) => {
  try {
    const item = await Clothing.findOne({
      _id: req.params.id,
      userId: req.user._id,
    });
    if (!item) {
      res.status(404);
      throw new Error('Clothing item not found');
    }
    res.status(200).json({ success: true, clothing: item });
  } catch (error) {
    next(error);
  }
};

// @route  POST /api/clothes
// @access Private
const createClothing = async (req, res, next) => {
  try {
    if (!req.body.name || !req.body.category) {
      res.status(400);
      throw new Error('Name and category are required');
    }

    const data = { userId: req.user._id };
    EDITABLE_FIELDS.forEach((field) => {
      if (req.body[field] !== undefined) {
        data[field] = req.body[field];
      }
    });

    const item = await Clothing.create(data);
    res.status(201).json({
      success: true,
      message: 'Clothing item added successfully',
      clothing: item,
    });
  } catch (error) {
    next(error);
  }
};

// @route  PUT /api/clothes/:id
// @access Private
const updateClothing = async (req, res, next) => {
  try {
    const item = await Clothing.findOne({
      _id: req.params.id,
      userId: req.user._id,
    });
    if (!item) {
      res.status(404);
      throw new Error('Clothing item not found');
    }

    // Only apply known fields; never userId/owner
    EDITABLE_FIELDS.forEach((field) => {
      if (req.body[field] !== undefined) {
        item[field] = req.body[field];
      }
    });

    const updated = await item.save();
    res.status(200).json({
      success: true,
      message: 'Clothing item updated successfully',
      clothing: updated,
    });
  } catch (error) {
    next(error);
  }
};

// @route  DELETE /api/clothes/:id
// @access Private
const deleteClothing = async (req, res, next) => {
  try {
    const item = await Clothing.findOne({
      _id: req.params.id,
      userId: req.user._id,
    });
    if (!item) {
      res.status(404);
      throw new Error('Clothing item not found');
    }

    await item.deleteOne();

    // Keep saved outfits consistent: drop the reference to the deleted item
    await Outfit.updateMany(
      { userId: req.user._id, items: item._id },
      { $pull: { items: item._id } }
    );

    res.status(200).json({
      success: true,
      message: 'Clothing item deleted successfully',
    });
  } catch (error) {
    next(error);
  }
};

// @route  PATCH /api/clothes/:id/favorite
// @access Private
const toggleFavorite = async (req, res, next) => {
  try {
    const item = await Clothing.findOne({
      _id: req.params.id,
      userId: req.user._id,
    });
    if (!item) {
      res.status(404);
      throw new Error('Clothing item not found');
    }

    item.isFavorite = !item.isFavorite;
    await item.save();

    res.status(200).json({
      success: true,
      message: item.isFavorite ? 'Added to favorites' : 'Removed from favorites',
      clothing: item,
    });
  } catch (error) {
    next(error);
  }
};

// @route  PATCH /api/clothes/:id/worn
// @access Private
const markAsWorn = async (req, res, next) => {
  try {
    const item = await Clothing.findOne({
      _id: req.params.id,
      userId: req.user._id,
    });
    if (!item) {
      res.status(404);
      throw new Error('Clothing item not found');
    }

    item.timesWorn += 1;
    await item.save();

    res.status(200).json({
      success: true,
      message: `Marked as worn (${item.timesWorn} times)`,
      clothing: item,
    });
  } catch (error) {
    next(error);
  }
};

module.exports = {
  getClothes,
  getStats,
  getClothingById,
  createClothing,
  updateClothing,
  deleteClothing,
  toggleFavorite,
  markAsWorn,
};
