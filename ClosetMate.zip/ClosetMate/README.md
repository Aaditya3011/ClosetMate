# ClosetMate

A personal wardrobe management system. Organize your clothes, create outfits, track usage, and get simple rule-based outfit suggestions.

## Tech Stack

- **Frontend:** React, Vite, Bootstrap 5, React Router
- **Backend:** Node.js, Express.js
- **Database:** MongoDB Atlas (Mongoose)
- **Auth:** JWT, bcryptjs

## Project Structure

```
MiniProject\
├── frontend\   React app (Vite)
├── backend\    Express REST API
├── .gitignore
└── README.md
```

## Getting Started

Coming soon — setup instructions will be added as development phases are completed.

## License

College minor project.
